from typing import List

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class ManifactureVariableTransformer(BaseEstimator, TransformerMixin):
	# Manifacture extractration from Name transformer

    def __init__(self, variables: List[str]):
        
        if not isinstance(variables, list):
            raise ValueError('variables should be a list')
        
        self.variables = variables

    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        # we need this step to fit the sklearn pipeline
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:

    	# so that we do not over-write the original dataframe
        X = X.copy()

        X.insert(0, 'Manifacture', X["Name"].str.extract('(\w+)'))
        
        # for feature in self.variables:
        #     # Extract Manifacture from Name
        #     X["Manifacture"] = X.loc[:, feature].str.extract('(\w+)')
            # X.insert(0, 'Manifacture', X[feature].str.extract('(\w+)'))


        return X


class MileageVariableTransformer(BaseEstimator, TransformerMixin):
	#  Extraction the part number of Mileage transformer

    def __init__(self, variables: List[str]):
        
        if not isinstance(variables, list):
            raise ValueError('variables should be a list')
        
        self.variables = variables

    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        # we need this step to fit the sklearn pipeline
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:

    	# so that we do not over-write the original dataframe
        X = X.copy()

        X.insert(8, 'Mileage_ext',  X["Mileage"].str.extract('(\d+\.\d+)').astype('float'))
        
        # for feature in self.variables:
        #     # Extract number from Mileage
        #     X.insert(8, 'Mileage_ext',  X[feature].str.extract('(\d+\.\d+)').astype('float'))

        return X

class PowerVariableTransformer(BaseEstimator, TransformerMixin):
    # Extraction of the part number of Power tranformer

    def __init__(self, variables: List[str]):
        if not isinstance(variables, list):
            raise ValueError('variable should be a list')

        self.variables = variables

    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()

        X.insert(10, 'Power_ext',  X["Power"].str.extract('(\d+\.*\d*)').astype('float'))

        # for feature in self.variables:
        #     # Extract number for Power
        #     X.insert(10, 'Power_ext',  X[feature].str.extract('(\d+\.*\d*)').astype('float'))
        
        return X

class NewPriceVariableTransformer(BaseEstimator, TransformerMixin):
    # Extraction of the part number of New_Price tranformer

    def __init__(self, variables: List[str]):
        if not isinstance(variables, list):
            raise ValueError('variable should be a list')

        self.variables = variables

    def fit(self, X: pd.DataFrame, y:pd.Series = None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()

        X.insert(11, 'New_Price_ext',  X["New_Price"].str.extract('(\d+\.*\d*)').astype('float'))

        # for feature in self.variables:
        #     # Extract number for New_Price
        #     X.insert(11, 'New_Price_ext',  X[feature].str.extract('(\d+\.*\d*)').astype('float'))
        
        return X


class EngineVariableTransformer(BaseEstimator, TransformerMixin):
    # Extraction of the part number of Engine tranformer

    def __init__(self, variables: List[str]):
        if not isinstance(variables, list):
            raise ValueError('variable should be a list')

        self.variables = variables

    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()

        X.insert(9, 'Engine_ext', X["Engine"].str.extract('(\d+)').astype('float'))

        # for feature in self.variables:
            # Extract number for Engine
            # X.insert(9, 'Engine_ext', X[feature].str.extract('(\d+)').astype('float'))
        
        return X


# categorical missing value imputer
class Mapper(BaseEstimator, TransformerMixin):

    def __init__(self, variables: List[str], mappings: dict):

        if not isinstance(variables, list):
            raise ValueError('variables should be a list')

        self.variables = variables
        self.mappings = mappings

    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        # we need the fit statement to accomodate the sklearn pipeline
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()

        X["Owner_Type"] = X["Owner_Type"].map(self.mappings)
        # for feature in self.variables:
        #     X[feature] = X[feature].map(self.mappings)

        return X