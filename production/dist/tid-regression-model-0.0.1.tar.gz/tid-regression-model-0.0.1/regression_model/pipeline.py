from feature_engine.encoding import OneHotEncoder, RareLabelEncoder
from feature_engine.imputation import (
    AddMissingIndicator,
    CategoricalImputer,
    MeanMedianImputer,
)
from feature_engine.selection import DropFeatures
from sklearn.feature_selection import SelectFromModel
from feature_engine.transformation import (
    LogTransformer,
    YeoJohnsonTransformer,
)
from feature_engine.wrappers import SklearnTransformerWrapper
from sklearn.linear_model import Lasso
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import Binarizer, MinMaxScaler

from regression_model.config.core import config
from regression_model.processing import features as pp

car_pipe = Pipeline(
    [
        # == VARIABLES EXTRACTION ====
        ('manifacture', pp.ManifactureVariableTransformer(
                variables=config.model_config.name_vars
            )            
        ),
        
        ('mileage', pp.MileageVariableTransformer(
                variables=config.model_config.mileage_vars
            )
        ),
        
        ('engine', pp.EngineVariableTransformer(
                variables=config.model_config.engine_vars
            )
        ),
        
        ('power', pp.PowerVariableTransformer(
                variables=config.model_config.power_vars
            )
        ),
        
        ('new_price', pp.NewPriceVariableTransformer(
                variables=config.model_config.new_price_vars
            )
        ),

        # drop features
        ('drop_features', DropFeatures(features_to_drop=
                                    [
                                        config.model_config.name_vars_drop, 
                                        config.model_config.mileage_vars_drop,
                                        config.model_config.engine_vars_drop, config.model_config.power_vars_drop,
                                        config.model_config.new_price_vars_drop
                                    ])),
        # ===== IMPUTATION =====
        # add missing indicator
        (
            "missing_indicator",
            AddMissingIndicator(
                variables=config.model_config.numerical_vars_with_na
            ),
        ),
        # impute numerical variables with the mean
        (
            "mean_imputation",
            MeanMedianImputer(
                imputation_method="mean",
                variables=config.model_config.numerical_vars_with_na,
            ),
        ),
       
        # ==== VARIABLE TRANSFORMATION =====
        ("log", LogTransformer(
                variables=config.model_config.numericals_log_vars,
            )
        ),

        ("yeojohnson", YeoJohnsonTransformer(
                variables=config.model_config.numericals_yeo_vars,
            )
        ),
       
        # === mappers ===
        (
            "mapper_owner",
            pp.Mapper(
                variables=config.model_config.owner_type_vars,
                mappings=config.model_config.owner_mappings,
            ),
        ),
    
        # == CATEGORICAL ENCODING
        (
            "rare_label_encoder",
            RareLabelEncoder(
                tol=0.01, n_categories=1, variables=config.model_config.categorical_vars,
            ),
        ),
        # encode categorical variables using the target mean
        (
            "categorical_encoder",
            OneHotEncoder(top_categories=30,
                drop_last=False,
            ),
        ),
        ("scaler", MinMaxScaler()),

        # feature selection
        ('selector', SelectFromModel(
            Lasso(
                alpha=config.model_config.alpha, 
                random_state=config.model_config.random_state,
                ),
            ),
        ),

        (
            "Lasso",
            Lasso(
                alpha=config.model_config.alpha,
                random_state=config.model_config.random_state,
            ),
        ),
    ]
)
